Formal topology edge export (2026-11-14)

This archive contains the 140 canonical edge lists and the machine-readable audit files needed to validate them.

Contents:
- edge_lists/: 20 real, 20 identity and 100 degree-preserving rewired graphs;
- formal_edge_constraint_audit.csv;
- formal_gateb_hash_audit.csv;
- formal_gateb_edge_ablation_metrics.csv;
- formal_split_feature_manifest.json;
- formal_gateb_edge_export_manifest.json;
- mismatch_resolution.csv;
- topology_audit_status.json.

After extraction, run:
python repro/audits/validate_reconstructed_edge_lists.py --root formal_topology_edge_export
